import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HealthserviceService } from './healthservice.service';

@Component({
  selector: 'app-viewcustomers',
  templateUrl: './viewcustomers.component.html',
  styleUrls: ['./viewcustomers.component.css']
})
export class ViewcustomersComponent implements OnInit {

  customers:any[]=[];
  constructor(private router:Router,private service:HealthserviceService) { }

  ngOnInit() {
    this.service.getCustomers().subscribe((data:any)=>this.customers=data);
  }
  onSearch(value){
    console.log(value);
    this.customers=this.customers.filter(b=>b.mail.toLowerCase().match(value.toLowerCase()));
  }
  goHome(){
    this.router.navigate(['./gohome'])

  }
 
}
