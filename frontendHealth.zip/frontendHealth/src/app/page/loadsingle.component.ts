import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-loadsingle',
  templateUrl: './loadsingle.component.html',
  styleUrls: ['./loadsingle.component.css']
})
export class LoadsingleComponent implements OnInit {

  constructor(private router:Router,private service:EmployeeService) { }
model:any={};

  ngOnInit() {
  }
  onCancel(){
    this.router.navigate(['./menupage']);
  }
  onLoadBulk1(){
    this.router.navigate(['./loadbulk']);
  }
  onView1(){
    this.router.navigate(['./viewpage']);
  }
  onModify1(){
    this.router.navigate(['./modifypage']);
  }
 goHome(){
  this.router.navigate(['./menupage']);
 }
 goLogout1(){
  this.router.navigate(['./loginpage']);
 }
 onSelectSingle(){
  this.router.navigate(['./loadsingle/singlenextpage']);
 }
 onSelectCancel(){
  this.router.navigate(['./menupage']);
 }

 addEmployee():any{
   console.log(this.model);
   this.service.addEmployee(this.model).subscribe();
 }

}
