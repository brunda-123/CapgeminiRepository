import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HealthserviceService } from './healthservice.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-techreg',
  templateUrl: './techreg.component.html',
  styleUrls: ['./techreg.component.css']
})
export class TechregComponent implements OnInit {
  model:any={}
  result:boolean
  constructor(private router:Router,private service:HealthserviceService) { }

  ngOnInit() {
  }
  // login(){
  //   this.router.navigate(['./logi'])
  
  
  onSubmit(userForm){
    
    console.log("hello");
    console.log(userForm);
    this.service.addTechnician(userForm).subscribe()
    alert("Registered Successfully")
    this.router.navigate(['./log1']);
    }
   
    
  techlog(){
    this.router.navigate(['./techlog'])
  }
  gohome(){
    this.router.navigate(['./homex'])
  }

}