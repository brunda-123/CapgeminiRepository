import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HealthserviceService } from './healthservice.service';

@Component({
  selector: 'app-viewtechnicians',
  templateUrl: './viewtechnicians.component.html',
  styleUrls: ['./viewtechnicians.component.css']
})
export class ViewtechniciansComponent implements OnInit {

  technician:any[]=[];
  constructor(private router:Router,private service:HealthserviceService) { }

  ngOnInit() {
    this.service.getTechnician().subscribe((data:any)=>this.technician=data);
  }
  onSearch(value){
    console.log(value);
    this.technician=this.technician.filter(b=>b.contactNoT.toLowerCase().match(value.toLowerCase()));
  }
  goHome(){
    this.router.navigate(['./gohome'])

  }
 

}
