import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HealthserviceService } from './healthservice.service';

@Component({
  selector: 'app-customerlog',
  templateUrl: './customerlog.component.html',
  styleUrls: ['./customerlog.component.css']
})
export class CustomerlogComponent implements OnInit {
flag:any;
  constructor(private router:Router,private service:HealthserviceService) { }

  ngOnInit() {
  }
  customer(){
    this.router.navigate(['./customer1'])
  }


  onSubmit(value){
    this.service.testCustomer(value.email,value.password).subscribe(data=>{
      this.flag=data;
      console.log("data="+data);
      console.log("flag value");
    console.log(this.flag);
if(this.flag==true){
alert("Login Successfully")
  this.router.navigate(['./customer1'])
}
else{
  alert("Invalid Login")
  this.router.navigate(['./custlog'])
}
  
    });
  
this.service.addCustomerEmail(value.email);


  }
  custreg(){
    this.router.navigate(['registercv'])
  }
  gohome(){
    this.router.navigate(['./homex'])
  }
  goCustomer(){
    this.router.navigate(['./customerhome'])
  }
}
