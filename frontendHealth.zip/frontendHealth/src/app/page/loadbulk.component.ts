import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-loadbulk',
  templateUrl: './loadbulk.component.html',
  styleUrls: ['./loadbulk.component.css']
})
export class LoadbulkComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  } goHome(){
    this.router.navigate(['./menupage']);
  }
  goLogout(){
    this.router.navigate(['./loginpage']);
  }
  
  onLoadBulk1(){
    this.router.navigate(['./loadbulk']);
  }
  onView1(){
    this.router.navigate(['./viewpage']);
  }
  onModify1(){
    this.router.navigate(['./modifypage']);
  }

  onLoadSingle(){
    this.router.navigate(['./loadsingle']);
  }
}