import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manager1',
  templateUrl: './manager1.component.html',
  styleUrls: ['./manager1.component.css']
})
export class Manager1Component implements OnInit {

  a:boolean=false;

  constructor(private router:Router) { }

  ngOnInit() {
  }
  goHome(){
    this.a=true
console.log("hai");
  }
  goHomee(){
    this.router.navigate(['./home'])
  }
  menu(){
    this.router.navigate(['./menu1'])
  }


onEquip(){
  this.router.navigate(['./equip'])
  console.log("hello")
}
log(){
  this.router.navigate(['./log'])
}
onTest(){
  this.router.navigate(['./test'])
  console.log("hello")
}
add(){
  this.router.navigate(['./add'])
}
add1(){
  this.router.navigate(['./add1'])
}
view(){
  this.router.navigate(['./view'])
}
view1(){
this.router.navigate(['./view1'])
}
view2(){
  this.router.navigate(['./view2'])
}
technicians(){
  this.router.navigate(['./technicians'])
}
customers(){
  this.router.navigate(['./customers'])
}


}
