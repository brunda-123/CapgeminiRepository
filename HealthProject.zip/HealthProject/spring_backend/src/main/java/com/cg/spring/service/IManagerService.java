package com.cg.spring.service;

import java.util.Date;
import java.util.List;

import com.cg.spring.dto.Customer;
import com.cg.spring.dto.Customerbooking;
import com.cg.spring.dto.Equipment;
import com.cg.spring.dto.Manager;
import com.cg.spring.dto.Technician;
import com.cg.spring.dto.Test;

public interface IManagerService {
	void addEquipment(Equipment equipment);
	void addTest(Test test);
	List<Equipment> viewEquipment();
	List<Test> viewTest();
	void addManagerDetails(Manager admin);
	void addTechnician(Technician tech);
	void addCustomer(Customer customer);
	Boolean getTechLogin(String email,String password);
	Boolean getCustomerLogin(String email,String password);
	List<Technician> viewTechnician();
/*	void customerBooking(String testName,Date date);
*/	
	List<Customer> viewCustomers();
	void customerBooking(Customerbooking c);	
     List<Customerbooking> viewCustomers(String technicianEmail);
     void addBill(String customerEmail,String sampleType,Double bill);
     String getSample(String customerEmail);
     Double getBill(String customerEmail);
     List<Customerbooking> getBills(String email);
 	List<Customerbooking> viewCustomer();

}