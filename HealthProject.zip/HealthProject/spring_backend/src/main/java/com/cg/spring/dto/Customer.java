package com.cg.spring.dto;

public class Customer {
	
	private String name;
	private String mail;
	private String password;
	private String city;
	private String contactNo;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	
	@Override
	public String toString() {
		return "Customer [name=" + name + ", mail=" + mail + ", password=" + password + ", city=" + city
				+ ", contactNo=" + contactNo + "]";
	}
	public Customer(String name, String mail, String password, String city, String contactNo) {
		super();
		this.name = name;
		this.mail = mail;
		this.password = password;
		this.city = city;
		this.contactNo = contactNo;
		
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	 
	

	

	

}