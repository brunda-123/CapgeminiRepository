package com.cg.spring.dto;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="technician")
public class Technician {
	
	private String nameT;
	private String mailT;
	private String passwordT;
	private String cityT;
	private String timingsT;
	private String contactNoT;
	
	public String getNameT() {
		return nameT;
	}
	public void setNameT(String nameT) {
		this.nameT = nameT;
	}
	public String getMailT() {
		return mailT;
	}
	public void setMailT(String mailT) {
		this.mailT = mailT;
	}
	public String getPasswordT() {
		return passwordT;
	}
	public void setPasswordT(String passwordT) {
		this.passwordT = passwordT;
	}
	public String getCityT() {
		return cityT;
	}
	public void setCityT(String cityT) {
		this.cityT = cityT;
	}
	public String getTimingsT() {
		return timingsT;
	}
	public void setTimingsT(String timingsT) {
		this.timingsT = timingsT;
	}
	public String getContactNoT() {
		return contactNoT;
	}
	public void setContactNoT(String contactNoT) {
		this.contactNoT = contactNoT;
	}
	public Technician(String nameT, String mailT, String passwordT, String cityT, String timingsT,
			String contactNoT) {
		super();
	
		this.nameT = nameT;
		this.mailT = mailT;
		this.passwordT = passwordT;
		this.cityT = cityT;
		this.timingsT = timingsT;
		this.contactNoT = contactNoT;
	}
	public Technician() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Technician [nameT=" + nameT + ", mailT=" + mailT + ", passwordT=" + passwordT + ", cityT=" + cityT
				+ ", timingsT=" + timingsT + ", contactNoT=" + contactNoT + "]";
	}
	
	
	

}
