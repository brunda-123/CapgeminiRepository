package com.cg.spring.dto;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="Test")
public class Test {
	
	private String testName;
	
	public String getTestName() {
		return testName;
	}
	public void setTestName(String testName) {
		this.testName = testName;
	}
	public Test() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Test( String testName) {
		super();
		
		this.testName = testName;
	}
	@Override
	public String toString() {
		return "Test [testName=" + testName + "]";
	}

}
