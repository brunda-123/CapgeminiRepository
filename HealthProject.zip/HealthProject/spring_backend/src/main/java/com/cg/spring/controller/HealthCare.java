package com.cg.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.dto.Customer;
import com.cg.spring.dto.Customerbooking;
import com.cg.spring.dto.Equipment;
import com.cg.spring.dto.Manager;
import com.cg.spring.dto.Technician;
import com.cg.spring.dto.Test;
import com.cg.spring.service.ManagerService;


@RestController
@RequestMapping("/manager")
@CrossOrigin(origins="http://localhost:4200")

public class HealthCare {
	@Autowired
	private ManagerService managerService;
	
	@PostMapping("/addEquipment")
	public void addEquipment(@RequestBody Equipment equipment) {
		managerService.addEquipment(equipment);
	}
	@PostMapping("/addTest")
	public void addTest(@RequestBody Test test) {
		
		managerService.addTest(test);
	}
	@PostMapping("/addTech")
	public void addTechnician(@RequestBody Technician tech) {
		System.out.println("welcome controller"+tech);
		managerService.addTechnician(tech);
	}
	@PostMapping("/addCustomer")
	public void addCustomer(@RequestBody Customer customer) {
		System.out.println("welcome customer"+customer);
		managerService.addCustomer(customer);
	}
	
	@PostMapping("/addAdmin")
	void addAdmin(@RequestBody Manager admin) {
		System.out.println(admin);
		managerService.addManagerDetails(admin);
	}
	@GetMapping("/validatingTech/{mailT}/{passwordT}")
	Boolean getTechLogin(@PathVariable("mailT") String mailT,@PathVariable("passwordT") String passwordT ) {
		System.out.println("validating:"+mailT+passwordT);
		return managerService.getTechLogin(mailT, passwordT);
	}
	
	@GetMapping("/validatingCustomer/{mail}/{password}")
	Boolean getCustomerLogin(@PathVariable("mail") String mail,@PathVariable("password") String password ) {
		return managerService.getCustomerLogin(mail,password);
	}
	
@GetMapping("/viewTest")
public List<Test> viewTest() {
	List<Test> tests=managerService.viewTest();
	return tests;
}
@GetMapping("/viewTechnician")
public List<Technician> viewTech(){
	return managerService.viewTechnician();
}

@GetMapping("/viewCustomerInTech/{technicianMailId}")
public List<Customerbooking> viewCustomers(@PathVariable("technicianMailId") String technicianMailId){
	System.out.println("in view cust:"+technicianMailId);
	return managerService.viewCustomers(technicianMailId);
}

//@PostMapping("/bookTechnician")
//public void customerbook(@RequestBody Customerbooking customerbooking) {
	//System.out.println("customerbook");
	//System.out.println(customerbooking.getCustomerEmail());
	//System.out.println(customerbooking.getSampleType());
	//managerService.customerBooking(customerbooking);
	
	
//}

@PostMapping("/customerbooked")
public void customerBooking(@RequestBody Customerbooking customerbook) {
	System.out.println("customer booked"+customerbook);
	managerService.customerBooking(customerbook);
}

@GetMapping("/getEquipment")
public List<Equipment> viewEquipment() {
	List<Equipment> equipments=managerService.viewEquipment();
	return equipments;
	
}
@GetMapping("/getBill/{customerEmail}")
public  Double getBill(@PathVariable("customerEmail") String email) {
	System.out.println("in get bill controller:"+email);
	return managerService.getBill(email);
}


@GetMapping("/getSample/{customerEmail}")
public String getSample(@PathVariable("customerEmail") String email) {
	System.out.println("in get bill controller:"+email);
	System.err.println();
	return managerService.getSample(email);
}
@GetMapping("getSamples/{customerEmail}")
public List<Customerbooking> getBills(@PathVariable("customerEmail") String email) {
	System.out.println("in samples controller :"+email);
	System.out.println(managerService.getBills(email));
	return managerService.getBills(email);
}

@PutMapping("/addBill/{customerEmail}/{sampleType}/{bill}")
public void addBill(@PathVariable("customerEmail") String email,
		@PathVariable("sampleType") String sample,@PathVariable("bill") Double bill)
{
	System.out.println("in add bill:"+email+sample+bill);
	managerService.addBill(email, sample, bill);
}

}
