package com.cg.spring.dto;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="customerbooked")
public class Customerbooking {
   @Id
   private String customerEmail;
  private String technicianMailId;
    private String testName;
    private String sampleType;
    private Date dateOfAppointment;
    private Double bill;
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public String getTechnicianMailId() {
		return technicianMailId;
	}
	public void setTechnicianMailId(String technicianMailId) {
		this.technicianMailId = technicianMailId;
	}
	public String getTestName() {
		return testName;
	}
	public void setTestName(String testName) {
		this.testName = testName;
	}
	public String getSampleType() {
		return sampleType;
	}
	public void setSampleType(String sampleType) {
		this.sampleType = sampleType;
	}
	public Date getDateOfAppointment() {
		return dateOfAppointment;
	}
	public void setDateOfAppointment(Date dateOfAppointment) {
		this.dateOfAppointment = dateOfAppointment;
	}
	public Double getBill() {
		return bill;
	}
	public void setBill(Double bill) {
		this.bill = bill;
	}
	@Override
	public String toString() {
		return "Customerbooking [customerEmail=" + customerEmail + ", technicianMailId=" + technicianMailId
				+ ", testName=" + testName + ", sampleType=" + sampleType + ", dateOfAppointment=" + dateOfAppointment
				+ ", bill=" + bill + "]";
	}
	public Customerbooking(String customerEmail, String technicianMailId, String testName, String sampleType,
			Date dateOfAppointment, Double bill) {
		super();
		this.customerEmail = customerEmail;
		this.technicianMailId = technicianMailId;
		this.testName = testName;
		this.sampleType = sampleType;
		this.dateOfAppointment = dateOfAppointment;
		this.bill = bill;
	}
	public Customerbooking() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}