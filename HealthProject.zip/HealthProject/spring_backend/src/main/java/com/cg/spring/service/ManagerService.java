package com.cg.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.dao.ManagerDao;
import com.cg.spring.dto.Customer;
import com.cg.spring.dto.Customerbooking;
import com.cg.spring.dto.Equipment;
import com.cg.spring.dto.Manager;
import com.cg.spring.dto.Technician;
import com.cg.spring.dto.Test;

@Service
public class ManagerService implements IManagerService{
	
	@Autowired
	private ManagerDao managerDao;

	@Override
	public void addEquipment(Equipment equipment) {
		// TODO Auto-generated method stub
		managerDao.addEquipment(equipment);
	}

	@Override
	public void addTest(Test test) {
		// TODO Auto-generated method stub
		managerDao.addTest(test);
		
	}

	
	
	@Override
	public List<Test> viewTest() {
		// TODO Auto-generated method stub
		return managerDao.viewTest();
	}

	@Override
	public void addManagerDetails(Manager admin) {
		// TODO Auto-generated method stub
		managerDao.addManagerDetails(admin);
		
	}

	@Override
	public void addTechnician(Technician tech) {
		// TODO Auto-generated method stub
		managerDao.addTechnician(tech);
	}

	@Override
	public void addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		managerDao.addCustomer(customer);
	}

	@Override
	public Boolean getTechLogin(String email, String password) {
		// TODO Auto-generated method stub
		return managerDao.getTechLogin(email, password);
	}

	@Override
	public Boolean getCustomerLogin(String email, String password) {
		// TODO Auto-generated method stub
		return managerDao.getCustomerLogin(email, password);
	
	
	
}

	@Override
	public List<Technician> viewTechnician() {
		// TODO Auto-generated method stub
		return managerDao.viewTechnician();
	}

	/*@Override
	public void customerBooking(String testName, Date date) {
		// TODO Auto-generated method stub
		managerDao.customerBooking(testName, date);
	}*/
	@Override
	public void customerBooking(Customerbooking c) {
		// TODO Auto-generated method stub
		managerDao.customerBooking(c);
	}

	
	@Override
	public List<Equipment> viewEquipment() {
		// TODO Auto-generated method stub
		return managerDao.viewEquipment();
	}

	@Override
	public List<Customerbooking> viewCustomers(String technicianEmail) {
		// TODO Auto-generated method stub
		return managerDao.viewCustomers(technicianEmail);
	}

	@Override
	public void addBill(String customerEmail, String sampleType, Double bill) {
		// TODO Auto-generated method stub
		System.out.println("hii");
		managerDao.addBill(customerEmail, sampleType, bill);
	}

	@Override
	public String getSample(String customerEmail) {
		// TODO Auto-generated method stub
		return managerDao.getSample(customerEmail);
	}

	@Override
	public Double getBill(String customerEmail) {
		// TODO Auto-generated method stub
		return managerDao.getBill(customerEmail);
	}

	@Override
	public List<Customerbooking> getBills(String email) {
		// TODO Auto-generated method stub
		return managerDao.getBills(email);
	}

	@Override
	public List<Customerbooking> viewCustomer() {
		// TODO Auto-generated method stub
		return managerDao.viewCustomer();
	}

	@Override
	public List<Customer> viewCustomers() {
		// TODO Auto-generated method stub
		return managerDao.viewCustomers();
	}
}