package com.cg.spring.dto;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="equipments")
public class Equipment {

private String equipmentName;

public Equipment() {
	super();
	// TODO Auto-generated constructor stub
}
public Equipment(String equipmentName) {
	super();
	
	this.equipmentName = equipmentName;
	
}

public String getEquipmentName() {
	return equipmentName;
}
public void setEquipmentName(String equipmentName) {
	this.equipmentName = equipmentName;
}

@Override
public String toString() {
	return "Equipment [ equipmentName=" + equipmentName + "]";
}

}
