package com.cg.spring.dto;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="manager")
public class Manager {
	@Override
	public String toString() {
		return "Manager [userName=" + userName + ", password=" + password + "]";
	}
	private String userName;
	private String password;
	public Manager() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Manager(String userName, String password) {
		super();
		this.userName = userName;
		this.password = password;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	

}
