import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { MenuComponent } from './page/menu.component';

import { RegistrationComponent } from './registration.component';
import { LoadsingleComponent } from './page/loadsingle.component';
import { LoadbulkComponent } from './page/loadbulk.component';


import { ViewComponent } from './page/view.component';
import { ManagerComponent } from './page/manager.component';
import { Manager1Component } from './page/manager1.component';
import { AddComponent } from './page/add.component';
import { Add1Component } from './page/add1.component';
import { TechregComponent } from './page/techreg.component';
import { TechlogComponent } from './page/techlog.component';
import { TechnicianComponent } from './page/technician.component';
import { CustomerregComponent } from './page/customerreg.component';
import { CustomerlogComponent } from './page/customerlog.component';
import { CustomerComponent } from './page/customer.component';
import { BooktechniciansComponent } from './page/booktechnicians.component';

import { View1Component } from './page/view1.component';
import { ViewcustomerdetailsComponent } from './page/viewcustomerdetails.component';
import { AddcustomerdetailsComponent } from './page/addcustomerdetails.component';
import { ViewbillsComponent } from './page/viewbills.component';
import { Booktechnicians2Component } from './page/booktechnicians2.component';
import { ViewtechniciansComponent } from './page/viewtechnicians.component';
import { ViewcustomersComponent } from './page/viewcustomers.component';
import { CustomerviewComponent } from './page/customerview.component';





 

const routes: Routes = [
  {path:'loginpage',component:LoginComponent},
  {path :'menupage',component:MenuComponent},
  
  
  {path :'registrationpage',component:RegistrationComponent},
 
  {path:'viewpage',component:ViewComponent},
  {path:'manage',component:ManagerComponent},
  {path:'manage1',component:Manager1Component},
  {path:'techlog',component:TechlogComponent},
 {path:'menu1',component:MenuComponent},
 {path:'add',component:AddComponent},
 {path:'add1',component:Add1Component},
 {path:'tech',component:TechregComponent},
 {path:'technician',component:TechnicianComponent},
 {path:'logoutmenu',component:MenuComponent},
 {path:'customer',component:CustomerviewComponent},
 {path:'custlog',component:CustomerlogComponent},
 {path:'customer1',component:CustomerComponent},
 {path:'gomanager1',component:BooktechniciansComponent},
 {path:'view1',component:ViewComponent},
 {path:'view2',component:View1Component },
 {path:'customer2',component: CustomerComponent},
 {path:'goview2',component:ViewcustomerdetailsComponent},
 {path:'accept',component:AddcustomerdetailsComponent},
 {path:'technicianhomepage',component:TechnicianComponent},
 {path:'viewbills',component:ViewbillsComponent},
 {path:'manager1',component:Manager1Component},
 {path:'manager2',component:Manager1Component},
 {path:'add5',component:MenuComponent},
 {path:'booktech',component:Booktechnicians2Component},
 {path:'manage1',component:Manager1Component},
 {path:'gohome',component:Manager1Component},
 {path:'customers',component:ViewcustomersComponent},
 {path:'registercv',component:CustomerregComponent},
{path:'customerhome',component:CustomerComponent},
 {path:'technicians',component:ViewtechniciansComponent},
 {path:'homex',component:MenuComponent},
 {path:'menus',component:MenuComponent},
 {path:'customerhome1',component:BooktechniciansComponent},
 {path:'managg',component:ManagerComponent},

 
 {path:'logout',component:MenuComponent},

 

{path:'log1',component:TechlogComponent},
  
  
  
  {path :'', redirectTo:'/menupage', pathMatch:'full'}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  //imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
