import { TestBed } from '@angular/core/testing';

import { HealthserviceService } from './healthservice.service';

describe('HealthserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: HealthserviceService = TestBed.get(HealthserviceService);
    expect(service).toBeTruthy();
  });
});
