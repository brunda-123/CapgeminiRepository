import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HealthserviceService } from './healthservice.service';

@Component({
  selector: 'app-customerview',
  templateUrl: './customerview.component.html',
  styleUrls: ['./customerview.component.css']
})
export class CustomerviewComponent implements OnInit {

  technician:any[]=[];
  constructor(private router:Router,private service:HealthserviceService) { }

  ngOnInit() {
    this.service.getTechnician().subscribe((data:any)=>this.technician=data);
  }
  goHome(){
    this.router.navigate(['./custlog'])
  }
  homex(){
    this.router.navigate(['./add5'])
  }

}
