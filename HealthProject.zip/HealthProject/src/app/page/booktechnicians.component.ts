import { Component, OnInit } from '@angular/core';
import { HealthserviceService } from './healthservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-booktechnicians',
  templateUrl: './booktechnicians.component.html',
  styleUrls: ['./booktechnicians.component.css']
})
export class BooktechniciansComponent implements OnInit {
technician:any[]=[];
  constructor(private router:Router,private service:HealthserviceService) { }

  ngOnInit() {
    this.service.getTechnician().subscribe((data:any)=>this.technician=data);
  }
  bookTech(mail,name,city){
    this.service.addTechnicianEmail(mail,name,city);
    this.router.navigate(['./booktech'])
  }
  goHome(){
    this.router.navigate(['./customerhome'])
  }
  

}
