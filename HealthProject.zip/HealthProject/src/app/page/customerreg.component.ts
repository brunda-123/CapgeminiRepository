import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HealthserviceService } from './healthservice.service';

@Component({
  selector: 'app-customerreg',
  templateUrl: './customerreg.component.html',
  styleUrls: ['./customerreg.component.css']
})
export class CustomerregComponent implements OnInit {
values:any;
  constructor(private router:Router,private service:HealthserviceService) { }

  ngOnInit() {
  }
  custlog(){
    this.router.navigate(['./custlog'])
  }
  onSubmit(values){
    console.log(values);
  this.service.addCustomer(values).subscribe();
  alert("Registered Successfully")
  this.router.navigate(['./custlog']);
  }
  gohome(){
    this.router.navigate(['./homex'])
  }

}
