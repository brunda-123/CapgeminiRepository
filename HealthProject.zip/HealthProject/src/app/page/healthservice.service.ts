import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HealthserviceService {
  id:Number;
customerEmail:String;
customerMailInTech:String;
customerTestName:String;
customerName:String;
cusEmail:String;
techName:String;
techCity:String;
customerCity:String;
technicianEmail:String;
techMailInTechLog:String;
  constructor(private http:HttpClient) { }
  addTechnician(data:any){
    console.log("in service"+data.name)
    
    let input={"nameT":data.name,"mailT":data.email,
    "passwordT":data.password,"cityT":data.city,"timingsT":data.timings,
    "contactNoT":data.contact};
    console.log(input)
  return this.http.post("http://localhost:8112/manager/addTech",input);
  }
    addCustomerBooking(value){
  //  let input={"customerEmail":this.customerEmail,"technicianMailId":this.technicianEmail,
  //  "testName":value.sample,"sampleType":null,
  // "dateOfAppointment":value.dateOfAppointment,"bill":0.00};  

   let input={"customerEmail":this.customerEmail,"technicianMailId":this.technicianEmail,
    "testName":value.sample,"sampleType":null,"dateOfAppointment":value.dateOfAppointment,
    "bill":0.00};
   console.log(input);
 return this.http.post("http://localhost:8112/controllerBooking/bookingCustomer",input);
  
  }
  getCustomers(){
    return this.http.get("http://localhost:8112/controllerBooking/getCustomers");
  }
  addTest(testname:String){
    console.log(testname)
    let input={"testName":testname};
    return this.http.post("http://localhost:8112/manager/addTest",input);
  }
  addEquipment(equipmentname:String){
    console.log(equipmentname)
    let input={"equipmentName":equipmentname};
    return this.http.post("http://localhost:8112/manager/addEquipment",input);
  }
  getTest(){
    return this.http.get("http://localhost:8112/manager/viewTest");
  }
  getEquipment(){
    return this.http.get("http://localhost:8112/manager/getEquipment");
  }
  testTech(mail,password){
    console.log(mail,password);
    return this.http.get("http://localhost:8112/manager/validatingTech/"+mail+"/"+password);
  }
  getTechnician(){
    return this.http.get("http://localhost:8112/manager/viewTechnician");
  }
  testCustomer(mail,password)
{
  return this.http.get("http://localhost:8112/manager/validatingCustomer/"+mail+"/"+password);
}  
  addCustomer(data:any){
   let input={"name":data.name,"mail":data.email,"password":data.password,
    "city":data.password,"contactNo":data.cno}
this.customerName=data.name;
this.customerCity=data.city;
console.log("in service:"+this.customerName);
  return this.http.post("http://localhost:8112/manager/addCustomer",input);
    }

    addCustomerEmail(email:any){
     // let input={"customerName":email};
    console.log("customer email:"+email);
      this.customerEmail=email;
      console.log("in add customer email:"+this.customerEmail);
     // return this.http.put("http://localhost:8112/manager/addCustomerEmail/",input);
    }
    addTechnicianEmail(mail,name,city){
      console.log("technician email :"+mail);
      this.technicianEmail=mail;
      this.techName=name;
      this.techCity=city;
      console.log("in tech customer email:"+this.customerEmail);
     // let input={"technicianMailId":email};
     // return this.http.put("http://localhost:8112/manager/addTechnicianEmail/",input);
    }
    getName(){
      return this.techName;
    }
    getCity(){
      return this.techCity;
    }
    addTechEmailInTechLog(mail){
      this.techMailInTechLog=mail;
      console.log("in techlog mail:"+this.techMailInTechLog);
    }
    getCustomersInTech(){
      return this.http.get("http://localhost:8112/manager/viewCustomerInTech/"+this.techMailInTechLog);
    }

    addTestName(email,testName){
      this.customerMailInTech=email;
      this.customerTestName=testName;
     
    }
    sendCustomerEmail(){
      return(this.customerMailInTech);
    }
    sendTestName(){
      console.log("in send testName:"+this.customerMailInTech);
      return(this.customerTestName);
    }
    addBill(value){
      console.log("In service add cust:"+value.sample+value.bill);
      console.log("this.custMailintech:"+this.customerMailInTech);
 return this.http.put("http://localhost:8112/manager/addBill/"+this.customerMailInTech+"/"
 +value.sample+"/"+value.bill,this.customerMailInTech);
    }

    getSample(){
      console.log("in get sample:"+this.customerEmail);
  this.cusEmail=this.customerEmail;
      return this.http.get("http://localhost:8112/manager/getSamples/"+this.cusEmail);
    }
    getSamples(){
      console.log(this.http.get("http://localhost:8112/manager/getSamples/"+this.customerEmail));
      return this.http.get("http://localhost:8112/manager/getSamples/"+this.customerEmail);
    }
    getBill(){
      return this.http.get("http://localhost:8112/manager/getBill/"+this.customerEmail);
    }

  }

  