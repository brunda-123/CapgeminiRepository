import { Component, OnInit } from '@angular/core';
import { HealthserviceService } from './healthservice.service';
import { Router } from '@angular/router';
//import 'rxjs/Rx'; 

@Component({
  selector: 'app-booktechnicians2',
  templateUrl: './booktechnicians2.component.html',
  styleUrls: ['./booktechnicians2.component.css']
})

 
export class Booktechnicians2Component implements OnInit {
  id:Number;
  name:String;
  city:String;
  constructor(private service:HealthserviceService,private router:Router) { }

  ngOnInit() {
    this.name=this.service.getName();
    this.city=this.service.getCity();
  }
  onSubmit1(value){

    this.id=Math.random()*300;
    console.log("value:"+value.sample+" date: "+value.dateOfAppointment); 
    console.log("id :"+this.id);
    this.service.addCustomerBooking(value).subscribe((data:any)=>{
      if(data==1)
      alert("success");
    });
    console.log("input",value);
    this.router.navigate(['./customerhome'])
  }
  goHome(){
    this.router.navigate(['./customerhome1'])
  }
  

}
