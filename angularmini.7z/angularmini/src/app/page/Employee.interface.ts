
    export interface IEmployee{
        eid:number,
        fname:string,
        lname:string,
        gender:string,
        dob:Date,
        doj:Date,
        bid:number,
        mid:number
    }
