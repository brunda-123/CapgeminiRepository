import { Component, OnInit } from '@angular/core';
import { HealthserviceService } from './healthservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add1',
  templateUrl: './add1.component.html',
  styleUrls: ['./add1.component.css']
})
export class Add1Component implements OnInit {
testname:String;
  constructor(private service:HealthserviceService,private router:Router) { }

  ngOnInit() {
    
  }
  addTest(){
    if(this.testname!=null){
    console.log(this.testname);
    alert("u added "+this.testname);
    this.service.addTest(this.testname).subscribe();
    this.router.navigate(['./manager2']);
  }
}
  homex()
  {
    this.router.navigate(['./manager1']);
  }



}
