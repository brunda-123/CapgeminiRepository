import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manager',
  templateUrl: './manager.component.html',
  styleUrls: ['./manager.component.css']
})
export class ManagerComponent implements OnInit {

  flag:Boolean;
u:any;
  constructor(private router:Router) { }

  ngOnInit() {
  }
  manag(){
    if(this.flag)
     this.router.navigate(['./manage1']);
   }
onSubmit(u){
  if(u.name=="meghana"&&u.password=="maggi")
  this.flag=true;
}
menu(){
  this.router.navigate(['./menus'])
}
}

