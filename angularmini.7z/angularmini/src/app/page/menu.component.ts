import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
 // id:Number;
  a:boolean=false;
  constructor(private router:Router) {

   }

  ngOnInit() {
   // this.id=Math.random()*3000;
    //console.log("id value :"+this.id);
  }

  goHome(){
    this.a=true
console.log("hai");
  }
  
  


  goRegister(){
    this.router.navigate(['./reg'])
  }
  tech(){
    this.router.navigate(['./techlog'])
  }
  goManage(){
    this.router.navigate(['./manage'])
  }
  goCustomer(){
    this.router.navigate(['./customer'])
  }
  }