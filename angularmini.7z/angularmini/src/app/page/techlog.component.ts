import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HealthserviceService } from './healthservice.service';

@Component({
  selector: 'app-techlog',
  templateUrl: './techlog.component.html',
  styleUrls: ['./techlog.component.css']
})
export class TechlogComponent implements OnInit {
  flag:any;
  constructor(private router:Router,private service:HealthserviceService) { }

  ngOnInit() {
  }
  technician(){
    this.router.navigate(['./technician'])
  }
  onSubmit(value){
    this.service.testTech(value.email,value.password).subscribe(data=>{
      this.flag=data;
      console.log("data="+data);
      console.log("flag value");
    console.log(this.flag);
if(this.flag==true)
  this.router.navigate(['./technician'])
  else
  alert("invalid user");

  
    });
  
    this.service.addTechEmailInTechLog(value.email);
    alert("Login Successfully")

}
techreg(){
  this.router.navigate(['./tech'])
}
gohome(){
  this.router.navigate(['./homex'])
}
}