import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-technician',
  templateUrl: './technician.component.html',
  styleUrls: ['./technician.component.css']
})
export class TechnicianComponent implements OnInit {

  a:boolean=false;
  constructor(private router:Router) { }

  ngOnInit() {
  }

  goHome(){
    this.a=true
console.log("hai");
  }
  logoutmenu(){
    this.router.navigate(['./logoutmenu'])
  }
  goView2(){
    this.router.navigate(['./goview2']);
  }
  
 

}

