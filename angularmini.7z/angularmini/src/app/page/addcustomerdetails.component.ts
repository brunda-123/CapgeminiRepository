import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HealthserviceService } from './healthservice.service';

@Component({
  selector: 'app-addcustomerdetails',
  templateUrl: './addcustomerdetails.component.html',
  styleUrls: ['./addcustomerdetails.component.css']
})
export class AddcustomerdetailsComponent implements OnInit {
customerEmail:String;
customerTest:String;
  constructor(private service:HealthserviceService,private router:Router) { }

  ngOnInit() {
   this.customerEmail=this.service.sendCustomerEmail();
   console.log("in cusEmail :"+this.customerEmail);
   this.customerTest=this.service.sendTestName();
  }
  onSubmit1(value){
    console.log("in add cust:"+value.sample+value.bill);
   this.service.addBill(value).subscribe();
   this.router.navigate(['./technicianhomepage'])
  }
  goHome(){
    this.router.navigate(['./technician'])
  }
  
}
