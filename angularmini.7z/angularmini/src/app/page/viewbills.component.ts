import { Component, OnInit } from '@angular/core';
import { HealthserviceService } from './healthservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewbills',
  templateUrl: './viewbills.component.html',
  styleUrls: ['./viewbills.component.css']
})
export class ViewbillsComponent implements OnInit {

  constructor(private service:HealthserviceService,private router:Router) { }
  samples:any[]=[];
    ngOnInit() {
      
    this.service.getSamples().subscribe((data:any)=>{
      console.log(data);
      this.samples=data;
    })
  
    }
    goHome(){
      this.router.navigate(['./customer2'])
    }
  }