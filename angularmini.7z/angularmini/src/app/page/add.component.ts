import { Component, OnInit } from '@angular/core';
import { HealthserviceService } from './healthservice.service';

import { Router } from '@angular/router';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
equipmentname:string;
  constructor(private service:HealthserviceService,private router:Router) { }

  ngOnInit() {
  }
  addEquipment(){
    if(this.equipmentname!=null){
    this.service.addEquipment(this.equipmentname).subscribe();
    alert("Equipment added successfully")
    this.router.navigate(['./manager1'])
    }

  }
  homex(){
    this.router.navigate(['./manager2'])
  }

}
