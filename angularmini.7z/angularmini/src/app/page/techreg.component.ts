import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HealthserviceService } from './healthservice.service';

@Component({
  selector: 'app-techreg',
  templateUrl: './techreg.component.html',
  styleUrls: ['./techreg.component.css']
})
export class TechregComponent implements OnInit {

  constructor(private router:Router,private service:HealthserviceService) { }

  ngOnInit() {
  }
  login(){
    this.router.navigate(['./logi'])
  }
  // goLogin(){

  //   this.router.navigate(['./log1'])
  // }
  onSubmit(userForm){
    //console.log(this.model);
    console.log("hello");
    console.log(userForm);
    this.service.addTechnician(userForm).subscribe();
    alert("Successfully Registered")
    this.router.navigate(['./log1'])
  }
  techlog(){
    this.router.navigate(['./techlog'])
  }
  gohome(){
    this.router.navigate(['./homex'])
  }

}