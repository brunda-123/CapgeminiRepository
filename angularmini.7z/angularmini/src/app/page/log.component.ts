import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './log.component.html',
  styleUrls: ['./log.component.css']
})
export class LogComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  }

  onSubmit(){
 
    this.router.navigate(['./menupage']);
  }
  onSignUp(){
    this.router.navigate(['./registrationpage']);
  }
  goLog(){
    this.router.navigate(['./customer']);
  }
}
