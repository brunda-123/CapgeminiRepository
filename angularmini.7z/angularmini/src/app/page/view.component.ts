import { Component, OnInit } from '@angular/core';
import { Router } from '../../../node_modules/@angular/router';
import { EmployeeService } from '../employee.service';
import { IEmployee } from './Employee.interface';
import { HealthserviceService } from './healthservice.service';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {
  equipments:any[]=[];
  constructor(private router:Router,private service:HealthserviceService) { }
  
  ngOnInit() {
    this.service.getEquipment().subscribe((data:any)=>this.equipments=data);

  
 
  }
  goHome(){
    this.router.navigate(['./gohome'])

  }
  
 
  
  } 
  
  

