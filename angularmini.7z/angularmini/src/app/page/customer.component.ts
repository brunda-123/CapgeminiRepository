import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  a:boolean=false;
  constructor(private router:Router) { }

  ngOnInit() {
  }

  goHome(){
    this.a=true
console.log("hai");
  }
  goManager1(){
this.router.navigate(['./gomanager1'])
  }
  viewBills(){
    this.router.navigate(['./viewbills'])
  }
  logout(){
    this.router.navigate(['./logoutmenu'])
  }
}
