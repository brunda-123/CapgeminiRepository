import { Component, OnInit } from '@angular/core';
import { HealthserviceService } from './healthservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewcustomerdetails',
  templateUrl: './viewcustomerdetails.component.html',
  styleUrls: ['./viewcustomerdetails.component.css']
})
export class ViewcustomerdetailsComponent implements OnInit {
customers:any[]=[];
  constructor(private service:HealthserviceService,private router:Router) { }

  ngOnInit() {
    this.service.getCustomersInTech().subscribe((data:any)=>this.customers=data);
console.log("hiii"+this.customers);
  }
accept(email,testName){
  this.service.addTestName(email,testName);
  this.router.navigate(['./accept']);
}
goHome(){
  this.router.navigate(['./technician'])
}
}
