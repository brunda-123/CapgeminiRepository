import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {ReactiveFormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { MenuComponent } from './page/menu.component';
import{LoadsingleComponent} from './page/loadsingle.component';
import { RegistrationComponent } from './registration.component';
import { LoadbulkComponent } from './page/loadbulk.component';
import {FormsModule} from '@angular/forms';
import { ViewComponent } from './page/view.component';


import { HttpClientModule } from '@angular/common/http';

import { ManagerComponent } from './page/manager.component';
import { Manager1Component } from './page/manager1.component';
import { AddComponent } from './page/add.component';
import { Add1Component } from './page/add1.component';
import { TechregComponent } from './page/techreg.component';
import { TechlogComponent } from './page/techlog.component';
import { TechnicianComponent } from './page/technician.component';
import { CustomerregComponent } from './page/customerreg.component';
import { CustomerComponent } from './page/customer.component';
import { CustomerlogComponent } from './page/customerlog.component';

import { BooktechniciansComponent } from './page/booktechnicians.component';

import{View1Component } from './page/view1.component';
import { from } from 'rxjs';
import { ViewbillsComponent } from './page/viewbills.component';
import { AddcustomerdetailsComponent } from './page/addcustomerdetails.component';
import { ViewcustomerdetailsComponent } from './page/viewcustomerdetails.component';
import { ViewcustomersComponent } from './page/viewcustomers.component';
import { ViewtechniciansComponent } from './page/viewtechnicians.component';
import { Booktechnicians2Component } from './page/booktechnicians2.component';
import { CustomerviewComponent } from './page/customerview.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    MenuComponent,
    LoadsingleComponent,
    RegistrationComponent,
    LoadbulkComponent,
    View1Component ,
    
    ViewComponent,
    
    
    
    ManagerComponent,
    
    
    
    Manager1Component,
    
    
    
    AddComponent,
    
    
    
    Add1Component,
    
    
    
    TechregComponent,
    
    
    
    TechlogComponent,
    
    
    
    TechnicianComponent,
    
    
    
    CustomerregComponent,
    
    
    
    CustomerComponent,
    
    
    
    CustomerlogComponent,
    
    
    
   
    
    
    
    BooktechniciansComponent,
    
    
    
   
    
    
    
  
    
    
    
   
    
    
    
    ViewbillsComponent,
    
    
    
   
    
    
    
    AddcustomerdetailsComponent,
    
    
    
   
    
    
    
    ViewcustomerdetailsComponent,
    
    
    
   
    
    
    
    ViewcustomersComponent,
    
    
    
   
    
    
    
    ViewtechniciansComponent,
    
    
    
   
    
    
    
    Booktechnicians2Component,
    
    
    
   
    
    
    
    CustomerviewComponent,
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
