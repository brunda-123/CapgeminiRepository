package com.cg.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.dto.Customer;
import com.cg.spring.dto.Customerbooking;
import com.cg.spring.service.ManagerService;

@RestController
@RequestMapping("/controllerBooking")
@CrossOrigin(origins="http://localhost:4200")
public class CustomerBooking {
	@Autowired
	private ManagerService managerService;
	@PostMapping("/bookingCustomer")
	public Integer insertBooking(@RequestBody Customerbooking customerbooking) {
		System.out.println("in customerbooking controller"+customerbooking);
		managerService.customerBooking(customerbooking);
		return 1;
	}
	@GetMapping("/getCustomers")
	public List<Customer> viewCustomers(){
		return managerService.viewCustomers();
	}
	
}
