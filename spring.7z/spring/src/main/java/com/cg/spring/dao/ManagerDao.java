package com.cg.spring.dao;

import java.util.ArrayList;
import java.lang.Math; 

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.cg.spring.dto.Customer;
import com.cg.spring.dto.Customerbooking;
import com.cg.spring.dto.Equipment;
import com.cg.spring.dto.Manager;
import com.cg.spring.dto.Technician;
import com.cg.spring.dto.Test;

@Repository
public class ManagerDao implements IManager {
	@Autowired
	MongoTemplate mongoTemplate;
	Customerbooking customerB;

	@Override
	public void addEquipment(Equipment equipment) {
		// TODO Auto-generated method stub
		mongoTemplate.insert(equipment);
	}

	@Override
	public void addTest(Test test) {
		// TODO Auto-generated method stub
		mongoTemplate.insert(test);
	}

	@Override
	public List<Test> viewTest() {
		// TODO Auto-generated method stub
		
		List<Test> tests=mongoTemplate.findAll(Test.class);
		return tests;
	}

	@Override
	public void addManagerDetails(Manager admin) {
		// TODO Auto-generated method stub
		System.out.println("admin:"+admin);
		mongoTemplate.insert(admin);
	}

	@Override
	public void addTechnician(Technician tech) {
		// TODO Auto-generated method stub
		mongoTemplate.insert(tech);
		
	}

	@Override
	public void addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		mongoTemplate.insert(customer);
	}

	@Override
	public Boolean getTechLogin(String email,String password) {
		// TODO Auto-generated method stub
		System.out.println(email+","+password);
		List<Technician> technicians=mongoTemplate.findAll(Technician.class);
		for (Technician technician : technicians) {
			if(technician.getMailT().equals(email)&&technician.getPasswordT().equals(password))
				return true;
				
		}
		return false;
	}

	@Override
	public Boolean getCustomerLogin(String email, String password) {
		// TODO Auto-generated method stub
		List<Customer> customers=mongoTemplate.findAll(Customer.class);
		for (Customer customer : customers) {
			if(customer.getMail().equals(email)&&customer.getPassword().equals(password))
				return true;
		}
		return false;
	}

	@Override
	public List<Technician> viewTechnician() {
		// TODO Auto-generated method stub
		List<Technician> technicians=mongoTemplate.findAll(Technician.class);
		return technicians;
	}

		@Override
	public void customerBooking(Customerbooking c) {
		mongoTemplate.insert(c);
		
	}

	@Override
	public List<Equipment> viewEquipment() {
		// TODO Auto-generated method stub

		List<Equipment> equipment=mongoTemplate.findAll(Equipment.class);
		return equipment;
	}

	@Override
	public List<Customerbooking> viewCustomers(String technicianMailId) {
		// TODO Auto-generated method stub
		List<Customerbooking> customersReq=new ArrayList<Customerbooking>();
		List<Customerbooking> customers=mongoTemplate.findAll(Customerbooking.class);
		for (Customerbooking customerbooking : customers) {
			if(customerbooking.getTechnicianMailId()!=null && customerbooking.getTechnicianMailId().equals(technicianMailId)) 
				customersReq.add(customerbooking);
	
		}
					return customersReq;
	
	}

	@Override
	public void addBill(String customerEmail, String sampleType, Double bill) {
		// TODO Auto-generated method stub
        //double rand = Math.random(); 
        //rand=rand*300;
		System.out.println("In dao:"+customerEmail+sampleType+bill);
		List<Customerbooking> customers=mongoTemplate.findAll(Customerbooking.class);
		for (Customerbooking customerbooking : customers) {
		if(customerbooking.getCustomerEmail().equalsIgnoreCase(customerEmail)) {
			System.out.println("in dao:");
			customerbooking.setSampleType(sampleType);
			customerbooking.setBill(bill);
			//customerbooking.setId(rand);
			System.out.println(customerbooking);
			mongoTemplate.save(customerbooking);
		}
		}

	}

	@Override
	public String getSample(String customerEmail) {
		// TODO Auto-generated method stub

		List<Customerbooking> customers=mongoTemplate.findAll(Customerbooking.class);
		for (Customerbooking customerbooking : customers) {
			if(customerbooking.getCustomerEmail().equalsIgnoreCase(customerEmail)) {
				return customerbooking.getSampleType();
			}
		}
		return null;
	}

	@Override
	public Double getBill(String customerEmail) {
		// TODO Auto-generated method stub
		List<Customerbooking> customers=mongoTemplate.findAll(Customerbooking.class);
		for (Customerbooking customerbooking : customers) {
			if(customerbooking.getCustomerEmail()!=null && customerbooking.getCustomerEmail().equalsIgnoreCase(customerEmail)) {
				System.out.println(customerbooking.getBill());
				return customerbooking.getBill();
			}
		}
		return 0.00;
	}

	@Override
	public List<Customerbooking> getBills(String email) {
		// TODO Auto-generated method stub
		List<Customerbooking> c=new ArrayList<Customerbooking>();
		List<Customerbooking> customers=mongoTemplate.findAll(Customerbooking.class);
		for (Customerbooking customerbooking : customers) {
			if(customerbooking.getCustomerEmail().equalsIgnoreCase(email)) {
				c.add(customerbooking);
				System.out.println("in dao:"+c);
				return c;
			}
		}
		return null;
	}

	@Override
	public List<Customerbooking> viewCustomer() {
		// TODO Auto-generated method stub
		List<Customerbooking> customerbooking=mongoTemplate.findAll(Customerbooking.class);
		return customerbooking;
	}

	@Override
	public List<Customer>  viewCustomers() {
		// TODO Auto-generated method stub
		List<Customer> customer=mongoTemplate.findAll(Customer.class);
		return customer;
	}
	
	

}
