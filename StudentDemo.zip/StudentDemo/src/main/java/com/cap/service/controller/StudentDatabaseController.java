package com.cap.service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cap.service.dao.StudentdaoDef;
import com.cap.service.model.Student;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/StudentDatabaseController")
@Api(value="StudentDatabaseController", description="Operations pertaining to DB requests " )
public class StudentDatabaseController {

private StudentdaoDef studentdaoDef;
	
	
	
	@Autowired
	    public void setStudentdaoDef(StudentdaoDef studentdaoDef) {
	        this.studentdaoDef = studentdaoDef;
	    }

      
    /*
     * List all records
     */

    @ApiOperation(value = "View a list of available Records",response = Iterable.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved list"),
            @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")
    }
    )
    @RequestMapping(value = "/listStudent", method= RequestMethod.GET, produces = MediaType.APPLICATION_XML_VALUE )
    public Iterable<Student> listStudent(Model model){
    	Student student=new Student();    	
        @SuppressWarnings("unchecked")
		Iterable<Student> StudentList = (Iterable<Student>) studentdaoDef.listAllStudent(student);
        return StudentList;
    }
    
    /*
     * Show record by id
     */
    
    @ApiOperation(value = "Search a Record with an ID",response = Student.class)
    @RequestMapping(value = "/showStudent/{id}", method= RequestMethod.GET, produces=MediaType.APPLICATION_XML_VALUE)
    public Student showStudent(@PathVariable String id, Model model){
    	
    	
    	Student student=new Student();
    	student.setId(Integer.parseInt(id));
    	student= studentdaoDef.getStudentById(student);
	
    	return student;
    }
    
   
    @ApiOperation(value = "Delete a Student by id")
    @RequestMapping(value="/deleteStudent/{id}", method = RequestMethod.DELETE, produces=MediaType.APPLICATION_XML_VALUE)
    public ResponseEntity delete(@PathVariable String id){
    	Student student=new Student();
    	student.setId(Integer.parseInt(id));
    	studentdaoDef.deleteStudent(student);
        return new ResponseEntity("Student deleted successfully", HttpStatus.OK);

   }
    
    @ApiOperation(value = "Save Student")
    @RequestMapping(value="/saveStudent", method = RequestMethod.POST, produces=MediaType.APPLICATION_XML_VALUE)
    public ResponseEntity saveStudent(@RequestBody Student student){
    	   	studentdaoDef.saveStudent(student);
    	return new ResponseEntity("Student saved successfully \n" ,	HttpStatus.OK);
   }

}
