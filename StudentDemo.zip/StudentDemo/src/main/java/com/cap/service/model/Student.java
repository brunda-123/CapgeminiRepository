package com.cap.service.model;

import java.io.Serializable;
import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;


import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name = "Student")

@Access(AccessType.FIELD)

public class Student implements Serializable {
	
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public Student() {
		
	}

public Student(Integer id, String Name,String dob, String phone,String gender) {
		super();
		this.id = id;
		NAME = Name;
		DOB=dob;
		PHONE = phone;
		GENDER=gender;
	}



@ApiModelProperty(notes = "The database generated product ID")

@Id
private Integer id;
private String NAME;
private String DOB;
private String PHONE;
private String GENDER;

public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}

public String getNAME() {
	return NAME;
}

public void setNAME(String nAME) {
	NAME = nAME;
}


public String getDOB() {
	return DOB;
}

public void setDOB(String dOB) {
	DOB = dOB;
}

public String getPHONE() {
	return PHONE;
}

public void setPHONE(String pHONE) {
	PHONE = pHONE;
}

public String getGENDER() {
	return GENDER;
}

public void setGENDER(String gENDER) {
	GENDER = gENDER;
}

@Override
public String toString() {
	return "ReqXMLLogging [id=" + id + ", NAME=" + NAME+", PHONE=" + PHONE+", GENDER=" + GENDER+"]";
}
}
