package com.cap.service.dao.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.cap.service.model.Student;
import com.cap.service.repository.StudentRepository;


@Service
@EnableTransactionManagement
public class StudentServiceImpl implements StudentService {
    
   
    private StudentRepository  studentRepository;
    

    @Autowired
    public void setStudentRepository(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }
   
           
	@Override
	public Iterable<Student> listAllStudent() {
		
        return studentRepository.findAll();
	}

	@Override
	public Student getStudentById(Integer id) {
		 
	        return studentRepository.findById(id).orElse(null);
	        
	}

	@Override
	public Student saveStudent(Student student) {
		 
	        return studentRepository.save(student);
	}

	@Override
	public void deleteStudent(Integer id) {
		
		studentRepository.deleteById(id);
		
	}

	@Override
	public void deleteAllStudent() {
		
		studentRepository.deleteAll();
	}
	
	
}
