package com.cap.service.dao;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cap.service.dao.service.StudentService;
import com.cap.service.model.Student;

@Component
public class StudentdaoImpl implements StudentdaoDef {
	private Logger log = LogManager.getLogger(StudentdaoImpl.class);
	
	private StudentService studentService;
	
	
	
	@Autowired
	    public void setStudentService(StudentService studentService) {
	        this.studentService = studentService;
	    }

	
	
	@Override
	public Iterable<Student> listAllStudent(Student student) {
		// TODO Auto-generated method stub
		log.info("calling  listAllStudent........");
		
		Iterable<Student> studentList=studentService.listAllStudent();
		
		
		return studentList;
	}


	@Override
	public Student getStudentById(Student student) {
		
		
		student=studentService.getStudentById(student.getId());
		
		return student;
	}


	@Override
	public Student saveStudent(Student student) {
		log.info("calling  saveRequest........");
		
		try {
			studentService.saveStudent(student);
				
		}catch(Exception e) {log.info("Exception::::"+e.getMessage());}
		return student;
	}


	@Override
	public Student deleteStudent(Student student) {
		
		studentService.deleteStudent(student.getId());
		return student;
	}
	
	



		
}
