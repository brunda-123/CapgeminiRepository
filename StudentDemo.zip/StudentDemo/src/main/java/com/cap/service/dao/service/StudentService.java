package com.cap.service.dao.service;



import com.cap.service.model.Student;


public interface StudentService {
	
	    
    /* Student defination  */
    
    Iterable<Student> listAllStudent();

    Student getStudentById(Integer id);

    Student saveStudent(Student student);

    void deleteStudent(Integer id);
    
    void deleteAllStudent();
}
