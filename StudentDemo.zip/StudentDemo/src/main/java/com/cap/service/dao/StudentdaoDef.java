package com.cap.service.dao;

import com.cap.service.model.Student;


public interface StudentdaoDef {
	
		
	public Iterable<Student> listAllStudent(Student student);
	
	public Student getStudentById(Student student);
	
	public Student saveStudent(Student student);
	
	public Student deleteStudent(Student student);
	
	
	

	
	

}
