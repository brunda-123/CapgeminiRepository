package com.capgemini.pecunia.exception;

public class PecuniaException extends Exception {
	private static final long serialVersionUID = 1752849715059047108L;

	public PecuniaException(String message) {

		super(message);
	}
}
