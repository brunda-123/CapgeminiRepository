package com.capgemini.pecunia.exception;
public class LoanDisbursalException extends Exception {
	
	private static final long serialVersionUID = -8632023119170631612L;

	public LoanDisbursalException(String message) {
		super(message);
	}
}
