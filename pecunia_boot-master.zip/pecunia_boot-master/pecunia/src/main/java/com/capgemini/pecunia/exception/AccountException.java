package com.capgemini.pecunia.exception;

public class AccountException extends Exception {
	private static final long serialVersionUID = -944503504057872921L;

	public AccountException(String message) {

		super(message);
	}
}
