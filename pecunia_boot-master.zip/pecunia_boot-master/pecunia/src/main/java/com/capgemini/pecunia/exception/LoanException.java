package com.capgemini.pecunia.exception;
public class LoanException extends Exception {
	private static final long serialVersionUID = -4321420372689738705L;
	public LoanException(String message) {
		super(message);

	}
}
