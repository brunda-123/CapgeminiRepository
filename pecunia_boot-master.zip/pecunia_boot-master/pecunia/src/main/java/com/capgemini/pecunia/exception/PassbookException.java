package com.capgemini.pecunia.exception;

public class PassbookException extends Exception {

	private static final long serialVersionUID = -891995465156654422L;

	public PassbookException(String message) {

		super(message);
	}
}
