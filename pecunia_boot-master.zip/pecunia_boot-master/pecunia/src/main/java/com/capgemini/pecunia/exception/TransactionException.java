package com.capgemini.pecunia.exception;

public class TransactionException extends Exception {
	private static final long serialVersionUID = -1361019094353776811L;

	public TransactionException(String message) {
		super(message);
	}

}
