# pecunia_boot
Spring boot application for PECUNIA.
