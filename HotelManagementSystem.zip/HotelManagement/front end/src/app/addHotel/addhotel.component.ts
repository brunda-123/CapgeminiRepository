import { Component, OnInit } from '@angular/core';
import { HotelService } from '../hotel.service';

@Component({
  selector: 'app-addhotel',
  templateUrl: './addhotel.component.html',
  styleUrls: ['./addhotel.component.css']
})
export class AddhotelComponent implements OnInit {
  data:any;

  constructor(private service:HotelService) { }
  onSubmit(hotelForm){
    this.service.addHotel(hotelForm).subscribe(result=>{
      this.data=result;
      if(this.data==1)
      alert("hotel addedd successfully");
      else
      alert("hotel is not added");
    });
  }

  ngOnInit() {
  }

}
