import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HotelService {
  mobile:any;
  indate:any;
  outdate:any;
  location:any;
  hotelId:any;

  constructor(private http:HttpClient) { }

  addUser(data){
      console.log("service"+data)
      let userinput={"mobileNumber":data.mobile,
      "userName":data.name,
       "emailId":data.email,
     "password":data.password
    
     
  }
  return this.http.post("http://localhost:9989/userController/adduser",userinput);

  }
  check(mobile,pwd){
    return this.http.get("http://localhost:9989/userController/login?mobileNumber="+mobile+"&password="+pwd);
  }
  hotelsDisplay(location){
    return this.http.get("http://localhost:9989/userController/hotelsdisplay?location="+location);

  }
  roomsDisplay(id,indate,outdate){
    return this.http.get("http://localhost:9989/userController/roomsdisplay?id="+id+"&checkInDate="+indate+"&checkOutDate="+outdate);
  }
  bookRoom(roomNumber){
    this.mobile=localStorage.getItem("userMobile");
    this.indate=localStorage.getItem("indate");
    this.outdate=localStorage.getItem("outdate");
    this.location=localStorage.getItem("location");
    this.hotelId=localStorage.getItem("hotelid");

    let userinput={"mobileNumber":this.mobile,
    "checkInDate":this.indate,
     "checkOutDate":this.outdate,
   "preferredLocation":this.location,
   "roomNo":[roomNumber],
   "hotelId":this.hotelId
  
   
}
console.log("user data"+userinput.checkInDate);
console.log("user data"+userinput.mobileNumber);
console.log("user data"+userinput.checkOutDate);
console.log("user data"+userinput.preferredLocation);
//console.log("user data"+userinput.roomNo);
console.log("user data"+userinput.hotelId);
    return this.http.post("http://localhost:9989/userController/bookRoom",userinput);
  }
  adminLogin(mobile,password){
    console.log("mobile"+mobile+password);
    
      return this.http.get("http://localhost:9989/admincontroller/login?mobileNumber="+mobile+"&password="+password);
    }
    viewHotels(){
      return this.http.get("http://localhost:9989/admincontroller/getHotelsList");
    }
    addHotel(data){
      let userinput={"hotelId":data.id,
      "hotelName":data.hotelname,
       "location":data.location
    
     
  }
      return this.http.post("http://localhost:9989/admincontroller/addhotel",userinput);
    }

    deleteHotel(id){
      return this.http.delete("http://localhost:9989/admincontroller/deletehotel?id="+id);
    }
    viewRooms(id){
      return this.http.get("http://localhost:9989/admincontroller/viewrooms?id="+id);
    }
    addRoom(data){
      
      let userinput={"hid":localStorage.getItem("hid"),
      "roomNumber":data.id,
       "price":data.roomprice,
       "amenities":data.amenti


    }
    console.log("hotel id"+data.hid);
    return this.http.post("http://localhost:9989/admincontroller/addrooms",userinput);
  }
}
