import { Component, OnInit } from '@angular/core';
import { HotelService } from '../hotel.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewrooms',
  templateUrl: './viewrooms.component.html',
  styleUrls: ['./viewrooms.component.css']
})
export class ViewroomsComponent implements OnInit {
  data:any=[];
  constructor(private service:HotelService,private router:Router) { }

  addRoom(){
    this.router.navigate(['/addroom']);
  }
  

  ngOnInit() {
    this.service.viewRooms(localStorage.getItem("hid")).subscribe(result=>this.data=result);

  }

}
