import { Component, OnInit } from '@angular/core';
import { HotelService } from '../hotel.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewhotels',
  templateUrl: './viewhotels.component.html',
  styleUrls: ['./viewhotels.component.css']
})
export class ViewhotelsComponent implements OnInit {
  data:any=[];
  message:any;

  constructor(private service:HotelService,private router:Router) { }
  add(){
    this.router.navigate(['/addhotel']);
  }
  delete(id){
    this.service.deleteHotel(id).subscribe(result=>{this.message=result;
    if(this.message==1)
    alert("hotel deleted successfully");
    else
    alert("hotel is not deleted");
    });
    window.location.reload();
  }
  checkRooms(id){
localStorage.setItem("hid",id);
this.router.navigate(['/viewrooms']);
  }

  ngOnInit() {
    this.service.viewHotels().subscribe(result=>this.data=result);

  }

}
