import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HotelService } from '../hotel.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  model:any={};
  value:any;

  constructor(private router:Router,private service:HotelService) { }
  back(){
this.router.navigate(['/home']);
  }
  onSubmit(){
  
    
    
    this.service.addUser(this.model).subscribe(data=>{
      this.value=data;
      console.log("this.value");
      if(this.value==1)
      alert("Registered Successfully");
      else
      alert(" already Registered");
      
    });
    window.location.reload(); 
  }

  ngOnInit() {
  }

}
