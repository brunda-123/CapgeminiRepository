import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './user-home/home.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { RegisterComponent } from './Register/register.component';
import { HotelHomeComponent } from './Hotel-Home/hotel-home.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import {DataTableModule} from "angular-6-datatable";
import { HotelDisplayComponent } from './Hotel-display/hotel-display.component';
import { RoomsDisplayComponent } from './Rooms-display/rooms-display.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { ViewhotelsComponent } from './viewhotels/viewhotels.component';
import { AddhotelComponent } from './addHotel/addhotel.component';
import { ViewroomsComponent } from './viewrooms/viewrooms.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { AddroomComponent } from './addroom/addroom.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    LogoutComponent,
    RegisterComponent,
    HotelHomeComponent,
    HotelDisplayComponent,
    RoomsDisplayComponent,
    AdminHomeComponent,
    ViewhotelsComponent,
    AddhotelComponent,
    ViewroomsComponent,
    ForgotpasswordComponent,
    AddroomComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,HttpClientModule,
    DataTableModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
