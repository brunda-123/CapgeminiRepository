import { Component, OnInit } from '@angular/core';
import { HotelService } from '../hotel.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-hotel-home',
  templateUrl: './hotel-home.component.html',
  styleUrls: ['./hotel-home.component.css']
})
export class HotelHomeComponent implements OnInit {
  model:any={};
  data:any=[];

  constructor(private service:HotelService,private router:Router) { }
  enter(){
    localStorage.setItem("location",this.model.location);
    localStorage.setItem("indate",this.model.in);
    localStorage.setItem("outdate",this.model.out);
    this.router.navigate(['/hoteldisplay']);

  }
  

  ngOnInit() {
    
  }

}
