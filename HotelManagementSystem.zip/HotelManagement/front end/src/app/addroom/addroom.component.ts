import { Component, OnInit } from '@angular/core';
import { HotelService } from '../hotel.service';

@Component({
  selector: 'app-addroom',
  templateUrl: './addroom.component.html',
  styleUrls: ['./addroom.component.css']
})
export class AddroomComponent implements OnInit {
  hid:any;

  constructor(private service:HotelService) { }

  onSubmit(roomForm){
    this.service.addRoom(roomForm).subscribe();
  }

  ngOnInit() {
    this.hid=localStorage.getItem("hid")
    
  }

}
