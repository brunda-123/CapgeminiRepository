import { Component, OnInit } from '@angular/core';
import { HotelService } from '../hotel.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-hotel-display',
  templateUrl: './hotel-display.component.html',
  styleUrls: ['./hotel-display.component.css']
})
export class HotelDisplayComponent implements OnInit {
  data:any=[];

  constructor(private service:HotelService,private router:Router) { }
  select(id){
    localStorage.setItem("hotelid",id);
    this.router.navigate(['/roomsdisplay']);
  }

  ngOnInit() {
    this.service.hotelsDisplay(localStorage.getItem("location")).subscribe(result=>{
      this.data=result;
    console.log("hotels data"+this.data)});
  }

}
