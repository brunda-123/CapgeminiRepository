package com.cg.hotelmanagementsystem.dto;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class RoomBooking {
	private Long mobileNumber;
	private String checkInDate;
	private String checkOutDate;
	private String preferredLocation;
	private List<Integer> roomNo;
	private Integer hotelId;
	
	
	
	
	public Long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getCheckInDate() {
		return checkInDate;
	}
	public void setCheckInDate(String checkInDate) {
		this.checkInDate = checkInDate;
	}
	public String getCheckOutDate() {
		return checkOutDate;
	}
	public void setCheckOutDate(String checkOutDate) {
		this.checkOutDate = checkOutDate;
	}
	public String getPreferredLocation() {
		return preferredLocation;
	}
	public void setPreferredLocation(String preferredLocation) {
		this.preferredLocation = preferredLocation;
	}
	
	public List<Integer> getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(List<Integer> roomNo) {
		this.roomNo = roomNo;
	}
	public Integer getHotelId() {
		return hotelId;
	}
	public void setHotelId(Integer hotelId) {
		this.hotelId = hotelId;
	}
	
	public RoomBooking() {
		super();
		// TODO Auto-generated constructor stub
	}
	public RoomBooking(Long mobileNumber, String checkInDate, String checkOutDate, String preferredLocation,
			List<Integer> roomNo, Integer hotelId) {
		super();
		this.mobileNumber = mobileNumber;
		this.checkInDate = checkInDate;
		this.checkOutDate = checkOutDate;
		this.preferredLocation = preferredLocation;
		this.roomNo = roomNo;
		this.hotelId = hotelId;
	}
	@Override
	public String toString() {
		return "RoomBooking [mobileNumber=" + mobileNumber + ", checkInDate=" + checkInDate + ", checkOutDate="
				+ checkOutDate + ", preferredLocation=" + preferredLocation + ", roomNo=" + roomNo + ", hotelId="
				+ hotelId + "]";
	}
	
	

}
