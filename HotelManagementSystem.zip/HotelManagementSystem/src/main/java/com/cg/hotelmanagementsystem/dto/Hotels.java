package com.cg.hotelmanagementsystem.dto;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Hotels {
	@Id
	private Integer hotelId;
	private String hotelName;
	private String location;
	private List<Rooms> roomsList;
	
	
	
	public List<Rooms> getRoomsList() {
		return roomsList;
	}
	public void setRoomsList(List<Rooms> roomsList) {
		this.roomsList = roomsList;
	}
	public Integer getHotelId() {
		return hotelId;
	}
	public void setHotelId(Integer hotelId) {
		this.hotelId = hotelId;
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	public Hotels() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Hotels(Integer hotelId, String hotelName, String location, List<Rooms> roomsList) {
		super();
		this.hotelId = hotelId;
		this.hotelName = hotelName;
		this.location = location;
		this.roomsList = roomsList;
	}
	@Override
	public String toString() {
		return "Hotels [hotelId=" + hotelId + ", hotelName=" + hotelName + ", location=" + location + ", roomsList="
				+ roomsList + "]";
	}
	
	
		
}
