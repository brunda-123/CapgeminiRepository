package com.cg.hotelmanagementsystem.dto;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class User {
	@Id
	private Long mobileNumber;
	private String userName;
	private String emailId;
	private String Address;
	
	private String password;
	
	
	
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public User(Long mobileNumber, String userName, String emailId, String address, String password) {
		super();
		this.mobileNumber = mobileNumber;
		this.userName = userName;
		this.emailId = emailId;
		Address = address;
		this.password = password;
	}
	public Long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		this.Address = address;
	}
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "User [mobileNumber=" + mobileNumber + ", userName=" + userName + ", emailId=" + emailId + ", Address="
				+ Address + ", password=" + password + "]";
	}
	
	
	

}
