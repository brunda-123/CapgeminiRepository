package com.cg.hotelmanagementsystem.dao;

import java.util.List;

import com.cg.hotelmanagementsystem.dto.AddRoom;
import com.cg.hotelmanagementsystem.dto.Admin;
import com.cg.hotelmanagementsystem.dto.Hotels;
import com.cg.hotelmanagementsystem.dto.Rooms;
import com.cg.hotelmanagementsystem.dto.User;

public interface HotelDao {
	public Integer addHotel(Hotels hotel);
	public List<Hotels> getHotelsList();
	public Integer deleteHotel(Integer id);
	public Integer addRoom(Rooms room);
	public List<Rooms> getRoomsList();
	public boolean userLogin(Long mobileNumber,String password);
	public Integer addAdmin(Admin user);
	
	Integer addRoom(AddRoom room);
	public List<Rooms> viewRooms(Integer id);
	
}
