package com.cg.hotelmanagementsystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hotelmanagementsystem.dao.UserDao;
import com.cg.hotelmanagementsystem.dto.Hotels;
import com.cg.hotelmanagementsystem.dto.RoomBooking;
import com.cg.hotelmanagementsystem.dto.Rooms;
import com.cg.hotelmanagementsystem.dto.User;

@Service
public class UserServiceImpl implements UserService{
	@Autowired
	UserDao userDao;

	@Override
	public Integer addUser(User user) {
		// TODO Auto-generated method stub
		return userDao.addUser(user);
	}

	@Override
	public boolean userLogin(Long mobileNumber, String password) {
		// TODO Auto-generated method stub
		return userDao.userLogin(mobileNumber, password);
	}

	@Override
	public List<Hotels> HotelsDisplay(String location) {
		// TODO Auto-generated method stub
		return userDao.HotelsDisplay(location);
	}

	@Override
	public List<Rooms> roomsDisplay(Integer id, String checkInDate, String checkOutDate) {
		// TODO Auto-generated method stub
		return userDao.roomsDisplay(id, checkInDate, checkOutDate);
	}

	@Override
	public Integer bookRoom(Long mobileNumber, String indate, String outdate, String location,
			List<Integer> roomNo,Integer id) {
		// TODO Auto-generated method stub
		return userDao.bookRoom(mobileNumber,indate,outdate,location,roomNo,id);
	}

	@Override
	public Integer bookRoom(RoomBooking roombooking) {
		// TODO Auto-generated method stub
		return userDao.bookRoom(roombooking);
	}

}
