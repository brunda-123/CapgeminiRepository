package com.cg.hotelmanagementsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.hotelmanagementsystem.dto.Hotels;
import com.cg.hotelmanagementsystem.dto.RoomBooking;
import com.cg.hotelmanagementsystem.dto.Rooms;
import com.cg.hotelmanagementsystem.dto.User;
import com.cg.hotelmanagementsystem.service.UserService;

@RestController
@RequestMapping("/userController")
@CrossOrigin("http://localhost:4200")
public class UserController {
	@Autowired
	UserService userService;
	
	@PostMapping("/adduser")
	public Integer addUser(@RequestBody User user) {
		int result=userService.addUser(user);
		if(result==1)
			return 1;
		else
			return 2;
	}
	@GetMapping("/login")
	public boolean userLogin(@RequestParam Long mobileNumber,@RequestParam String password) {
	return 	userService.userLogin(mobileNumber, password);
	}
	@GetMapping("/hotelsdisplay")
	public List<Hotels> hotelsDisplay(@RequestParam String location){
		return userService.HotelsDisplay(location);
		
	}
	
	@GetMapping("/roomsdisplay")
	public List<Rooms> roomsDisplay(@RequestParam Integer id,@RequestParam String checkInDate,@RequestParam String checkOutDate){
		return userService.roomsDisplay(id, checkInDate, checkOutDate);
	}
	
	@GetMapping("/bookRooms")
	public Integer bookRoom(@RequestParam Long mobileNumber,@RequestParam String indate,@RequestParam String outdate,@RequestParam String location,List<Integer> roomNo,@RequestParam Integer id) {
		System.out.println("in room booking");
		int result=userService.bookRoom(mobileNumber,indate,outdate,location,roomNo,id);
		if(result==1)
			return 1;
		else
			return 2;
	}
	
	@PostMapping("/bookRoom")
	public Integer bookRoom(@RequestBody RoomBooking roombook) {
		System.out.println("in room booking");
		int result=userService.bookRoom(roombook);
		if(result==1)
			return 1;
		else
			return 2;
	}
	

}
